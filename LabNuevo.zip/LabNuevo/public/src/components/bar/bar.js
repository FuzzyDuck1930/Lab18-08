class bar extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    static get observedAttributes(){
        return["coun1","coun2","coun3","coun4","coun5","coun6","flag1","flag2","flag3","flag4","flag5","flag6"]
    }

    attributeChangedCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    render(){
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/bar/bar.css">
        <div class="str8">
        <div class="country">
        <img class="pla" src="${this.flag1}" alt="">
        <p class="just1"><b>${this.coun1}</b></p>
        </div>
        <div class="country">
        <img class="pla" src="${this.flag2}" alt="">
        <p class="just2"><b>${this.coun2}</b></p>
        </div>
        <div class="country">
        <img class="pla" src="${this.flag3}" alt="">
        <p class="just3"><b>${this.coun3}</b></p>
        </div>
        <div class="country">
        <img class="pla" src="${this.flag4}" alt="">
        <p class="just4"><b>${this.coun4}</b></p>
        </div>
        <div class="country">
        <img class="pla" src="${this.flag5}" alt="">
        <p class="just5"><b>${this.coun5}</b></p>
        </div>
        <div class="country">
        <img class="pla" src="${this.flag6}" alt="">
        <p class="just6"><b>${this.coun6}</b></p>
        </div>
        </div>
        `
    }
}

customElements.define("my-bar",bar)
export default bar