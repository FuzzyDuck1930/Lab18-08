class card extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    static get observedAttributes(){
        return["imag","tit","desc","redir"]
    }

    attributeChangedCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    render(){
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/card/card.css">
        <div class="whole">
        <img class="owl" src="${this.imag}" alt="">
        <div class="whotex">
        <h1 class="titl">${this.tit}</h1>
        <p class="info">${this.desc}</p>
        <h2 class="GoTo">${this.redir}</h2>
        </div>
        </div>
        <hr>
        `
    }
}

customElements.define("my-card",card)
export default card