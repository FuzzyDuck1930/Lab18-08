class unav extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    static get observedAttributes(){
        return["logo","idiom"];
    }

    attributeChangedCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    render(){
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/unav/unav.css">
        <div class="d1">
        <img class="logie" src="${this.logo}" alt="">
        <h3 class="idio">${this.idiom}</h3>
        </div>
        `
    }
}

customElements.define("my-nav",unav);
export default unav