class banner extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    static get observedAttributes(){
        return["imeg","phrase","btn1","btn2"]
    }

    attributeChangedCallback(propName,oldValue,newValue){
        this[propName] = newValue;
    }

    render(){
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/banner/banner.css">
        <div class="all">
        <img class="planet" src="${this.imeg}" alt="">
        <div class"itall">
        <h1 class="welcome">${this.phrase}</h1>
        <div class="btns">
        <button class="st">${this.btn1}</button>
        <button class="nd">${this.btn2}</button>
        </div>
        </div>
        </div>
        `
    }
}

customElements.define("my-ban",banner)
export default banner