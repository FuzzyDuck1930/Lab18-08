import * as components from "./components/index.js"

class ListContainer extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode:"open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
            this.shadowRoot.innerHTML += `
            <link rel="stylesheet" href="./src/styles.css">

            <my-nav logo="https://d35aaqx5ub95lt.cloudfront.net/images/dca3b978d07a7dfc05adb1d5526e9e21.svg" idiom="IDIOMA DE LA PÁGINA: ESPAÑOL"></my-nav>


            <div class="d2">
            <my-ban imeg="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6bcbf0b2caf3a3678ae632_home%20earth.svg" phrase="¡La forma divertida, efectiva y gratis de aprender un idioma!" btn1="EMPIEZA AHORA" btn2="YA TENGO UNA CUENTA"></my-ban>
            </div>

            <my-bar flag1="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6e68cab05a4283d13db304_en.svg" coun1="INGLÉS" flag2="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6e68cae732ff74e5e35228_fr.svg" coun2="FRANCÉS" flag3="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6e68c92359057b643ed13a_de.svg" coun3="ALEMÁN" flag4="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6e68c96aa90f50aa3a9385_it.svg" coun4="ITALIANO" flag5="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6e68c9cf1eeb12bbc25cc4_bra.svg" coun5="PORTUGUÉS" flag6="https://assets.website-files.com/5f6ab89b45559536fe7e0394/5f6e68c9cf1eeb545fc25cc5_ko.svg" coun6="COREANO"></my-bar>


            <my-card imag="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcT_NY-7TIUpG7LL4ZvVdEpyop86BMXVVx4jT8BPibBoQy4yTnbT" tit="La forma #1 del mundo para aprender un idioma" desc="¡Aprender con Duolingo es divertido y <b>los estudios demuestran que funciona!</b> Con nuestras lecciones cortas ganarás puntos y accederás a nuevos niveles, todo mientras desarrollas tus capacidades comunicativas en la vida real." redir=""></my-card>
            <my-card imag="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSYq8Rz3RD9kGcfkzmWwLl-DuUd90T3tJqWhbG5i8ejSE_EHRlj" tit="Impulsa tu aprendizaje con Súper Duolingo" desc="En Duolingo, puedes aprender idiomas totalmente gratis, pero puedes eliminar los anuncios y apoyar la educación gratuita con Súper. ¡Te regalamos 2 semanas gratis!" redir="MÁS SOBRE SÚPER DUOLINGO"></my-card>
            <my-card imag="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSkqnNBAdVeSu1KVBReVohR_wX5JO6y6pZ6M7C3mfcof6uO7Mw1" tit="Aprende a cualquier hora, en cualquier lugar." desc="Haz que tus viajes y tiempo libre sean más productivos con la aplicación móvil de Duolingo. Descárgala y descubre por qué Apple y Google nos otorgaron sus premios más altos." redir="DESCÁRGALO EN GOOGLE PLAY"></my-card>
            <my-card imag="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRmxRJTvwv1pto7AF3XoU6czxR8y6R2rSmJeeKeok-4Vhq_-ueN" tit="Duolingo for Schools" desc="Una herramienta gratuita para maestros que ayuda a los estudiantes a aprender idiomas a través de la app de Duolingo, tanto dentro como fuera del salón de clases." redir="USA DUOLINGO EN TU SALÓN DE CLASES"></my-card>
            <my-card imag="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQO55iZ9P279ifV3mpHQk5yEYPAJUQ7MbL4nWRZoF-PCs1DKdQe" tit="Duolingo English Test" desc="Conoce el examen de inglés conveniente, rápido y económico, aceptado en todo el mundo. Gracias a la integración de los últimos avances en la ciencia de la evaluación e inteligencia artificial, los usuarios pueden hacer el examen cuando y dónde quieran." redir="CERTIFICA TU INGLÉS"></my-card>
            <my-card imag="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTJP5o63GViiH78ERHKwRQ16hsAsgiPe9SIogsdm7k8Em1t5fMc" tit="Cursos efectivos y eficientes" desc="Nuestros cursos enseñan a leer, escuchar y hablar de forma efectiva y eficiente. ¿Ya viste nuestros estudios más recientes?" redir="MÁS SOBRE NUESTROS ESTUDIOS"></my-card>
            `
    }
}

customElements.define("my-list",ListContainer)